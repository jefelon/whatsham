const path = require('path');
const { fileURLToPath } = require('url');

const dirName = path.dirname(__filename);

module.exports = dirName;
